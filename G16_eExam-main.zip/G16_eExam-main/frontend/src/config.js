const config = {
    // BACKEND_API:  "http://localhost:8000",
    BACKEND_API: "https://g16eexam-production.up.railway.app",
  };
  
  export default config;    